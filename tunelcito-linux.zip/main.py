import os
import subprocess
from colorama import init, Fore, Style
from src.sistema import *
from src.peticiones import *
init(autoreset=True)

if __name__ == "__main__":
    menu()
    token = leerTokenTXT()
    if (token[0]):
        idTunel = listaTuneles(token[1])
        if idTunel:
            response = iniciarTunelServidor(token[1],idTunel)
            if "tunel ya se encuentra" in response["menssage"]:
                print("al parerecer ya hay una sesion, apagar e iniciarla aqui?:")
                print(" (1) si")
                print(" (2) no")
                while True:
                    try:
                        opcion = int(input("Opcion: "))
                        if (opcion ==1 or opcion == 2):
                            break
                        else:
                            print("Opcion no validad, vuevle a intentarlo")
                    except:
                        print("Opcion no validad, vuevle a intentarlo")
                        pass
                if opcion ==1:
                    apagarTunelServidor(token[1],idTunel)
                    response = iniciarTunelServidor(token[1],idTunel)
                else:
                    response = False
                
        else:
            response = False
            vaciar_token()
        if response:
            print("idTunel:", idTunel)
            #print(response)


            subdominio = response["dominio"]
            tipo = response["tipo"]
            puerto_conexion = response["puerto_conexion"]
            puerto_salida = response["puerto_salida"]
            puerto_local= response["puerto_cliente"]
            #print(subdominio,tipo,puerto_conexion,puerto_salida,puerto_local)
            if generarArchivo(subdominio,tipo,puerto_conexion,puerto_local,puerto_salida):
                #print("archivo generado")
                try:
                    iniciarTunelCliente(subdominio,puerto_salida,puerto_local,tipo)
                except:
                    print("Apagando tunelcito ............................................")
                    apagarTunelServidor(token[1],idTunel)
                    print("Apagado :) BYE")
            else:
                print("archivo no generado")
        else:
            vaciar_token()
            print("tunel no iniciado correctamente")
    else:
        print(token[1])
        vaciar_token()