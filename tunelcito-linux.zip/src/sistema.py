import os
import subprocess
from colorama import init, Fore, Style

def menu():
    print(Fore.YELLOW + "-------------------------------------------")
    print(Fore.CYAN + Style.BRIGHT + "Bienvenido al cliente de Tunelcito :D\n")

    # Intentar leer el token desde el archivo
    if os.path.exists("src/token.txt") and os.path.getsize("src/token.txt") > 0:
        with open("src/token.txt", "r") as file:
            token = file.read().strip()
        print(Fore.GREEN + f"   Token obtenido del archivo: {token}")
    else:
        # Si el archivo está vacío, pedir al usuario que ingrese el token
        while True:
            token = input(Fore.YELLOW + "   Ingresa tu token: " + Fore.WHITE)
            if token.strip() and " " not in token:  # Verifica que no esté vacío y no tenga espacios
                with open("src/token.txt", "w") as file:
                    file.write(token)
                break
            else:
                print(Fore.RED + "   El token no puede contener espacios ni estar vacío. Intenta de nuevo.")
    
def vaciar_token():
    try:
        with open('src/token.txt', 'w') as archivo:
            archivo.truncate(0)  # Asegura que el archivo quede vacío
        return True, "Archivo vacío con éxito."
    except FileNotFoundError:
        return False, "El archivo no existe."
    except Exception as e:
        return False, f"Error al vaciar el archivo: {e}"

def leerTokenTXT():
    try:
        with open('src/token.txt', 'r') as archivo:
            return True,str(archivo.read())
    except:
        return False,"error al leer el archivo token.txt"

def generarArchivo(subdominio,tipo,puerto_conexion,puerto_local,puerto_salida):
    try:
        with open("src/"+subdominio, "w") as file:
            file.write(f"serverAddr = \"beta.tunelcito.com\"\n")
            file.write(f"serverPort = {puerto_conexion}\n")
            file.write(f"[[proxies]]\n")
            file.write(f"name = \"proxy-{subdominio}\"\n")
            if tipo == "web":
                file.write(f"type = \"http\"\n")
                file.write(f"subdomain = \"{subdominio}\"\n\n")
            elif tipo == "ssh":
                file.write(f"type = \"tcp\"\n")
                file.write(f"remotePort = {puerto_salida}\n")

            else:
                file.write(f"type = \"http\"\n")
            file.write(f"localIP = \"localhost\"\n")
            file.write(f"localPort = {puerto_local}\n")
            
        return True
    except Exception as e:
        print("error: ",e )
        return False
    

def iniciarTunelCliente(subdomain,puerto_salida,puerto_local,tipo):
    #base_url = "https://"
    base_url = "http://"
    base_url = ""
    domain = "beta.tunelcito.com"  # Cambia esto si tu dominio es diferente
     
    complete_url = f"{base_url}{subdomain}.{domain}:{puerto_salida}"
    print("\n\n\n\n")
    print("----------------------------------------------------------")
    if tipo == "web":
        print(Fore.BLUE + Style.BRIGHT + f"Tu url: "+Fore.YELLOW+f"{complete_url}\n")
    if tipo == "ssh":
        print(Fore.BLUE + Style.BRIGHT + f"Tu url: "+Fore.YELLOW+f"ssh tusuario@{domain} -p {puerto_salida}\n")
        
    print(Fore.BLUE + Style.BRIGHT + f"Escuchando: "+Fore.YELLOW+f"{puerto_local}\n")
    print("----------------------------------------------------------")
    # Iniciar frpc
    try:
        print(Fore.CYAN + "Iniciando frpc...\n")
        subprocess.run(['src/app', '-c', 'src/'+subdomain], check=True)
        print(Fore.GREEN + "frpc iniciado con éxito.")
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"Error al iniciar frpc: {e}")
    except FileNotFoundError:
        print(Fore.RED + "Error: No se encontró el ejecutable 'frpc'. Asegúrate de que esté en el directorio actual o en el PATH.")
