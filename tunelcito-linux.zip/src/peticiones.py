import requests
import json
import os
url = "https://tunelcito.com"
headers = {
   'Content-Type': 'application/json'
}

def listaTuneles(token):
    endpoint = url + "/tunelcito/consultar"
    payload = json.dumps({"token": token})
    response = requests.post(endpoint, headers=headers, data=payload)

    # Verificar si la respuesta es exitosa
    if response.status_code == 200:
        os.system('cls' if os.name == 'nt' else 'clear')
        try:
            # Convertir la respuesta a JSON
            response_json = response.json()
            if response_json["totalItems"]==0:
                print("No tienes tuneles creados")
            else:
                print(f"selecciona el tunel")
                for k in range(response_json["totalItems"]):
                    print(f"    ( {k+1} ) "+response_json["items"][k]["subdominio"])
                while True:
                    try:
                        opcion = int(input("opcion: "))
                        if opcion > 0 and opcion <= response_json["totalItems"]:
                            return response_json["items"][opcion-1]["id"]
                        
                    except:
                        print("opcion no validad intentelo de nuevo")
        except json.JSONDecodeError:
            print("Error al decodificar la respuesta JSON.")
            return False
    elif response.status_code == 400:
        print("----- Token no valido ------")
        return False
    else:
        print(f"Error: {response.status_code}")
        return False

def iniciarTunelServidor(token,idTunel):
    endpoint = url + "/tunelcito/iniciar"
    payload = json.dumps({"token": token,"tunelId":idTunel})
    response = requests.post(endpoint, headers=headers, data=payload)

    # Verificar si la respuesta es exitosa
    if response.status_code == 200:
        os.system('cls' if os.name == 'nt' else 'clear')
        try:
            # Convertir la respuesta a JSON
            response_json = response.json()
            return response_json
        except json.JSONDecodeError:
            print("Error al decodificar la respuesta JSON.")
            return False
    elif response.status_code == 400:
        print("----- Token no valido ------")
        return False
    else:
        print(f"Error: {response.status_code}")
        return False

def apagarTunelServidor(token,idTunel):
    endpoint = url + "/tunelcito/apagar"
    payload = json.dumps({"token": token,"tunelId":idTunel})
    response = requests.post(endpoint, headers=headers, data=payload)

    # Verificar si la respuesta es exitosa
    if response.status_code == 200:
        os.system('cls' if os.name == 'nt' else 'clear')
        try:
            # Convertir la respuesta a JSON
            response_json = response.json()
            return response_json
        except json.JSONDecodeError:
            print("Error al decodificar la respuesta JSON.")
            return False
    elif response.status_code == 400:
        print("----- Token no valido ------")
        return False
    else:
        print(f"Error: {response.status_code}")
        return False